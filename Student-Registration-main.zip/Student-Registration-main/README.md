# Student-Registration
Student Registration Form - Details displayed on the same page.

#Screeen Shots
![Screenshot 2023-09-16 202812](https://github.com/darsh5921/Student-Registration/assets/104684690/f2941daf-91c5-46dc-a724-e18e2224d665)
![Screenshot 2023-09-16 202846](https://github.com/darsh5921/Student-Registration/assets/104684690/b353353c-5267-4ea5-abf6-be164384e7df)
